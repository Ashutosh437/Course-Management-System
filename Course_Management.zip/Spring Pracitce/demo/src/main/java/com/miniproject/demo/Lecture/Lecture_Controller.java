package com.miniproject.demo.Lecture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Lectures")
public class Lecture_Controller {

    @Autowired
    Lecture_service lc;

    @PostMapping("/post")
    public ResponseEntity<Lecture> post(@RequestBody Lecture l){
         return lc.add(l);
    }
    @GetMapping("/getall")
    public ResponseEntity<List<Lecture_Dto>> getall(){
        return lc.getall();
    }
    @GetMapping("/getbyid/{Id}")
    public ResponseEntity<Lecture_Dto> getbyid(@PathVariable int id){
        return lc.getbyid(id);
    }

    @GetMapping("/getfull")
    public ResponseEntity<List<Lecture>> getfull(){
        return lc.getfull();
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Lecture> delete(@PathVariable int id){
        return lc.delete(id);
    }
}

