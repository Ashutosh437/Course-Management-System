package com.miniproject.demo.Resource;

public class Resource_Dto {
    public int id;
    public String name;
    public int size;
    public String url;
    public int lecture_id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLecture_id() {
        return lecture_id;
    }

    public void setLecture_id(int lecture_id) {
        this.lecture_id = lecture_id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static Resource_Dto converts (Resource r){

        Resource_Dto dt = new Resource_Dto();
        dt.setId(r.getId());
        dt.setName(r.getName());
        dt.setSize(r.getSize());
        dt.setLecture_id(r.getLectures().getId());
        dt.setUrl(r.getUrl());
        return dt;
    }

}
