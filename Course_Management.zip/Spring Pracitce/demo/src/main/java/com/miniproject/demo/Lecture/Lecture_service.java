package com.miniproject.demo.Lecture;

import com.miniproject.demo.Resource.Resource;
import com.miniproject.demo.Resource.Resource_repo;
import com.miniproject.demo.Sections.Section;
import com.miniproject.demo.Sections.Section_repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Lecture_service {
    @Autowired
    Lecture_repo lr;
     @Autowired
     Section_repo sr;
     @Autowired
     Resource_repo rr;
    public ResponseEntity<Lecture> add(Lecture l){

        Section s = sr.findById(l.getSections().getId()).orElseThrow(()-> new RuntimeException("no section with this id"));
       Resource r = rr.findById(l.getResources().getId()).orElseThrow(()->new RuntimeException("not found"));
        l.setSections(s);
        l.setResources(r);

        lr.save(l);
        return new ResponseEntity<>(l, HttpStatus.ACCEPTED);
    }



    public ResponseEntity<List<Lecture_Dto>> getall(){
        List<Lecture_Dto> lt = lr.findAll().stream().map(Lecture_Dto::convert).toList();

        if(lt.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(lt,HttpStatus.OK);
    }

    public ResponseEntity<Lecture_Dto> getbyid(int id){
        Optional<Lecture_Dto> op = lr.findById(id).map(Lecture_Dto::convert);
        if(op.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(op.get() ,HttpStatus.FOUND);
    }

    public ResponseEntity<List<Lecture>> getfull(){
        return new ResponseEntity<>(lr.findAll(),HttpStatus.OK);
    }

    public ResponseEntity<Lecture> delete(int id) {
        Optional<Lecture> o = lr.findById(id);

        if(o.isPresent()){
            lr.deleteById(id);
            return new ResponseEntity<>(o.get(),HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }
}
