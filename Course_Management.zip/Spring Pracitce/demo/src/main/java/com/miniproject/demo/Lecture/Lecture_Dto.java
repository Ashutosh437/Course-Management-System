package com.miniproject.demo.Lecture;

public class Lecture_Dto {

    private int id;
    private String name;
    private String resource_name;

    public String getResource_name() {
        return resource_name;
    }

    public void setResource_name(String resource_name) {
        this.resource_name = resource_name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static Lecture_Dto convert(Lecture l){

        Lecture_Dto ld = new Lecture_Dto();
        ld.setId(l.getId());
        ld.setName(l.getName());
        ld.setResource_name(l.getResources().getName());
        return ld;
    }

}
