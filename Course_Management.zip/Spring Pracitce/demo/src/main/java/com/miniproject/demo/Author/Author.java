package com.miniproject.demo.Author;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;


import java.time.LocalDate;

@Entity

 // lombok
public class Author {
   @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id = null;
    private String name;
   @Email
   @Column(unique = true)
    private String email;
    private int age;

    @Column(  insertable = false)
    private LocalDate last_update;
    @Column(updatable  = false)
    private LocalDate created_at;


       // MAPPING WITH COURSE
      /* @JsonBackReference("Authors-Courses")

      @ManyToMany(mappedBy = "authors")
        private List<Course> courses;


 public List<Course> getCourses() {
  return courses;
 }

 public void setCourses(List<Course> courses) {
  this.courses = courses;
 }

       */



 public Author(Integer id, String name, String email, int age,
               LocalDate last_update, LocalDate created_at) {
  this.id = id;
  this.name = name;
  this.email = email;
  this.age = age;
  this.last_update = last_update;
  this.created_at = created_at;
 }
public Author(){}
 public Integer getId() {
  return id;
 }

 public void setId(Integer id) {
  this.id = id;
 }

 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }

 public String getEmail() {
  return email;
 }

 public void setEmail(String email) {
  this.email = email;
 }

 public int getAge() {
  return age;
 }

 public void setAge(int age) {
  this.age = age;
 }

 public LocalDate getLast_update() {
  return last_update;
 }

 public void setLast_update(LocalDate last_update) {
  this.last_update = last_update;
 }

 public LocalDate getCreated_at() {
  return created_at;
 }

 public void setCreated_at(LocalDate created_at) {
  this.created_at = created_at;
 }
}
