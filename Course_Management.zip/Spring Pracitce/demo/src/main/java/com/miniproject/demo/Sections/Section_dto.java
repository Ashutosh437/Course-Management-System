package com.miniproject.demo.Sections;

import org.springframework.stereotype.Component;

@Component
public class Section_dto {
    private int id;
    private String name;
    private String Course_name;

    public String getCourse_name() {
        return Course_name;
    }

    public void setCourse_name(String course_name) {
        Course_name = course_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public static Section_dto convert(Section c){

         Section_dto dto = new Section_dto();
         dto.setId(c.getId());
         dto.setName(c.getName());
         dto.setCourse_name(c.getCourse_obj().getName());
         return dto;
    }


}
