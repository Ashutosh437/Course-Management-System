package com.miniproject.demo.Resource;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("video")
public class Video extends Resource {

    private int length;

    public Video(Integer id, String name, int size, String url) {
        super(id, name, size, url);
    }
  public Video(){
      super();
  }
    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
