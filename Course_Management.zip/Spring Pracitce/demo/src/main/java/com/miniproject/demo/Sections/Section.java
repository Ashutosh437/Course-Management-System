package com.miniproject.demo.Sections;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.miniproject.demo.Course.Course;
import com.miniproject.demo.Lecture.Lecture;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Section {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private int section_order;

    public Integer getId() {
        return id;
    }


    // Mapping with Course
  @JsonBackReference("Course-Section")
    @ManyToOne
    @JoinColumn(
            name = "course_id",
            referencedColumnName = "id"
    )
    private Course course_obj;

    // Mapping with Lecture//
    @JsonManagedReference("Section-Lecture")
    @OneToMany(
            mappedBy = "sections"
    )

    private List<Lecture> lectures;


      ////// GETTERS AND SETTERS //////
    public Section(){}

    public List<Lecture> getLectures() {
        return lectures;
    }

    public void setLectures(List<Lecture> lectures) {
        this.lectures = lectures;
    }

    public Course getCourse_obj() {
        return course_obj;
    }

    public void setCourse_obj(Course course_obj) {
        this.course_obj = course_obj;
    }

    public Section(Integer id, int order, String name) {
        this.id = id;
        this.section_order = order;
        this.name = name;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSection_order() {
        return section_order;
    }

    public void setSection_order(int section_order) {
        this.section_order = section_order;
    }
}
