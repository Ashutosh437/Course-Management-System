package com.miniproject.demo.Sections;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Section_repo  extends JpaRepository<Section,Integer> {
}
