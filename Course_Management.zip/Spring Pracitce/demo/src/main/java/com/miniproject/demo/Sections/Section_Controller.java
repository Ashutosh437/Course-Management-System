package com.miniproject.demo.Sections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Sections")
public class Section_Controller {

    @Autowired
    section_service srs;

    @PostMapping("/addsection")
    public Section post(@RequestBody Section sec){
        return srs.addsection(sec);
    }


    @GetMapping("/findviaid/{id}")
    public ResponseEntity<Section_dto> get(@PathVariable int id){
        return srs.getbyid(id);
    }

    @GetMapping("/getall")
    public ResponseEntity<List<Section_dto>> getall(){
        return srs.getall();
    }
}
