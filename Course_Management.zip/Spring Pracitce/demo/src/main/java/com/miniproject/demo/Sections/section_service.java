package com.miniproject.demo.Sections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class section_service {

    @Autowired
    Section_repo sr;

    public Section addsection(Section s){
    sr.save(s);
    return s;
}


    public ResponseEntity<List<Section_dto>> getall(){

    List<Section_dto> l = sr.findAll().stream().map(Section_dto::convert).toList();
    if(l.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    else{
        return new ResponseEntity<>(l,HttpStatus.FOUND);
    }
}


    public ResponseEntity<Section_dto> getbyid(int id){
         Optional<Section> sc = sr.findById(id);
          Optional<Section_dto> st = sc.map(Section_dto::convert);
    return st.map(sectionDto ->
            new ResponseEntity<>(sectionDto, HttpStatus.FOUND)).
            orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
}
















}
