package com.miniproject.demo.Resource;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.miniproject.demo.Lecture.Lecture;
import jakarta.persistence.*;

@Entity
@Inheritance(
        strategy = InheritanceType.SINGLE_TABLE
)

@DiscriminatorColumn(name = "Resource_Type")
public class Resource {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    private int size;

    private String url;


    // MAPPING WITH LECTURE
    @JsonBackReference("Lecture-Resource")
    @OneToOne(
            mappedBy = "resources"
    )

    private Lecture lectures;


    // GETTERS AND SETTERS

    public Lecture getLectures() {
        return lectures;
    }

    public void setLectures(Lecture lectures) {
        this.lectures = lectures;
    }

    public Resource(Integer id, String name, int size, String url) {
        this.id = id;
        this.name = name;
        this.size = size;
        this.url = url;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
   public Resource(){}
    public void setName(String name) {
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
