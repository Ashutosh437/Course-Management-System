package com.miniproject.demo.Lecture;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.miniproject.demo.Resource.Resource;
import com.miniproject.demo.Sections.Section;
import jakarta.persistence.*;

@Entity
public class Lecture {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;



 // Mapping with Section
    @JsonBackReference("Section-Lecture")
    @ManyToOne
    @JoinColumn(
            name = "section_id",
            referencedColumnName = "id"
    )
    private Section sections;



      // Mapping with Resource
    @JsonManagedReference("Lecture-Resource")
   @OneToOne(cascade = CascadeType.ALL)
   @JoinColumn(
           name = "resource_id",
           referencedColumnName = "id"
   )
    private Resource resources;

    public Resource getResources() {
        return this.resources;
    }

    public void setResources(Resource resources) {
        this.resources = resources;
    }

// Getters and Setters
    public  Lecture(){}
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Section getSections() {
        return sections;
    }

    public void setSections(Section sections) {
        this.sections = sections;
    }
}

