package com.miniproject.demo.Course;


import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.miniproject.demo.Sections.Section;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;


    private String description;

    public Integer getId() {
        return id;
    }

    public Course(Integer id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

        //MAPPING TO AUTHORS

       /*  @JsonManagedReference("Authors-Courses")
    @JoinTable(
            name = "Author_Course",

            joinColumns = {
                    @JoinColumn(name = "course_id", referencedColumnName = "id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "author_id",referencedColumnName = "id")
            }
    )
    @ManyToMany
      private List<Author> authors;



        */


    // Mapping with Sections

    @OneToMany(
            mappedBy = "course_obj"
    )
    @JsonManagedReference("Course-Section")
    private List<Section> section_obj;


    public List<Section> getSection_obj() {
        return section_obj;
    }

    public void setSection_obj(List<Section> section_obj) {
        this.section_obj = section_obj;
    }

   //public Course(String description, String name, Integer id) {
       // this.description = description;
      //  this.name = name;
     //   this.id = id;
  //  }
        public Course(){}
    public void setId(Integer id) {
        this.id = id;
    }

 /* public List<Author> getAuthors() {
        return authors;
    }

    public void setAuthors(List<Author> authors) {
        this.authors = authors;
    }

  */



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
