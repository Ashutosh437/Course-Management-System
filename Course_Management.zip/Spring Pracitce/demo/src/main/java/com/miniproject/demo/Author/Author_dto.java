package com.miniproject.demo.Author;

import org.springframework.stereotype.Component;

@Component
public class Author_dto {




}
