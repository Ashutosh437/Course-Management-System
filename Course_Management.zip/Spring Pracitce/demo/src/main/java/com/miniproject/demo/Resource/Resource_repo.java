package com.miniproject.demo.Resource;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Resource_repo extends JpaRepository<Resource,Integer> {
}
