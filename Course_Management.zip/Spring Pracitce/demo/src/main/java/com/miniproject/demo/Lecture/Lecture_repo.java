package com.miniproject.demo.Lecture;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Lecture_repo extends JpaRepository<Lecture,Integer> {

}
