package com.miniproject.demo.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Resources")
public class Resource_Controller {

    @Autowired
      Resource_Service rr;

    @PostMapping("/post")
    public ResponseEntity<Resource> post(@RequestBody Resource r){
        return rr.post(r);
    }
    @GetMapping("/getall")
    public ResponseEntity<List<Resource_Dto>> getall(){
        return rr.getall();
    }
    @GetMapping("/getbyid/{Id}")
    public ResponseEntity<Resource_Dto> getbyid(@PathVariable int id){
        return rr.getbyid(id);
    }

    @GetMapping("/getfull")
    public ResponseEntity<List<Resource>> getfull(){
        return rr.getfull();
    }

}


