package com.miniproject.demo.Course;

import com.miniproject.demo.Author.Author_repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class  Course_serivce {
    @Autowired
    Course_repo c_r;
  @Autowired
  Author_repo a_r;


    public ResponseEntity<Course> add_courses(Course c){
           c_r.save(c);
           return new ResponseEntity<>(c, HttpStatus.ACCEPTED);

    }

    public ResponseEntity<List<Course>> GetAllCourses(){
         List<Course> li = c_r.findAll();
           if(!li.isEmpty()){
               return new ResponseEntity<>(li,HttpStatus.FOUND);
           }
           return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    public ResponseEntity<Course> FindByid(int id){
        Optional<Course> obj = c_r.findById(id);
        return obj.map(course -> new ResponseEntity<>(course, HttpStatus.FOUND))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    public ResponseEntity<Course> deletecourse(int id){

        Optional<Course> obj = c_r.findById(id);
        if(obj.isPresent()){
            c_r.deleteById(id);
            return new ResponseEntity<>( obj.get(),HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
