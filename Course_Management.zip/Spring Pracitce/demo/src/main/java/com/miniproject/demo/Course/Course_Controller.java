package com.miniproject.demo.Course;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Coursess")
public class Course_Controller {

    @Autowired
    Course_serivce c_s;

    @PostMapping("/post")
    public void postcourse(@RequestBody Course c){

        c_s.add_courses(c);
    }

    @GetMapping("/getallcourse")

    public ResponseEntity<List<Course>> getcourse(){
        return c_s.GetAllCourses();
    }

    @GetMapping("/getcoursebyid/{id}")
    public ResponseEntity<Course> getcourse(@PathVariable int id){
        return c_s.FindByid(id);
    }

    @DeleteMapping("/deletecourse/{id}")
    public ResponseEntity<Course> deletecourse(@PathVariable int id){
        return c_s.deletecourse(id);
    }


}
