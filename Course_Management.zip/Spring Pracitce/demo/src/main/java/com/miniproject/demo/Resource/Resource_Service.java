package com.miniproject.demo.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Resource_Service {
    @Autowired
    Resource_repo rr;

    public ResponseEntity<Resource> post(Resource rt){

          rr.save(rt);
        return new ResponseEntity<>(rt, HttpStatus.OK);
    }


    public ResponseEntity<List<Resource_Dto>> getall(){
        List<Resource_Dto> rt = rr.findAll().stream().map(Resource_Dto::converts).toList();

        if(rt.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(rt,HttpStatus.OK);
    }

    public ResponseEntity<Resource_Dto> getbyid(int id){
        Optional<Resource_Dto> op = rr.findById(id).map(Resource_Dto::converts);
        if(op.isEmpty()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(op.get() ,HttpStatus.FOUND);
    }

    public ResponseEntity<List<Resource>> getfull(){
        return new ResponseEntity<>(rr.findAll(),HttpStatus.OK);
    }



}
