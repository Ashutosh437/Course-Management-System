package com.miniproject.demo.Author;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface Author_repo extends JpaRepository<Author,Integer> {
    @Query("Update Author a set a.age =:age where a.id = :id")
    public void UpdateAuthorAge(@Param("id") int id,@Param("age") int age);


}
