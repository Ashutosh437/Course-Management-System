package com.miniproject.demo.Course;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Course_repo extends JpaRepository<Course,Integer> {
}
